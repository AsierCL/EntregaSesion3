#ifndef COLORES_H
#define COLORES_H

// Colores de texto
#define ROJO     "\x1b[31m"
#define VERDE    "\x1b[32m"
#define AMARILLO "\x1b[33m"
#define AZUL     "\x1b[34m"
#define MAGENTA  "\x1b[35m"
#define CIAN     "\x1b[36m"
#define RESET    "\x1b[0m"

#endif // COLORES_H